package stepDefs;

import com.sun.tools.xjc.reader.gbind.ElementSets;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.junit.Assert;
import io.restassured.specification.RequestSpecification;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class BikeSearchStepDefs {
    private static final String BASE_URL = "https://api.citybik.es/v2/networks";
    private static RequestSpecification request;
    private static Response response;
    private static String jsonString;
     String actualLatitude;
     String actualLongitude;
    @Given("user prepares the headers and request body")
    public void userPreparesTheBikeSearchEndpoint() {

        RestAssured.baseURI = BASE_URL;
        request = RestAssured.given();
        request.header("Content-Type", "application/json");

    }

    @When("user calls the get bike search endpoint")
    public void userCallsTheGetBikeSearchEndpoint() {

        RestAssured.baseURI = BASE_URL;
        request = RestAssured.given();
        response = request.get();
        jsonString = response.asString();
    }

    @Then("validate the response code")
    public void validateTheResponseCode() {

        Assert.assertEquals(200, response.getStatusCode());
        System.out.println(response.getStatusCode());

    }


    @And("validate the response with {string} and {string} and Verify {string} and {string}")
    public void validateTheResponseWithAndAndVerifyAnd(String country, String city, String latitude, String longitude) {

        List<Map<String,String>> company = JsonPath.from(jsonString).get("networks.location");
        for(int i=0;i<=company.size()-1;i++)

        {
            if(company.get(i).get("country").equals(country)&& company.get(i).get("city").equals(city))
            {
                actualLatitude = String.valueOf(company.get(i).get("latitude"));
                actualLongitude = String.valueOf(company.get(i).get("longitude"));
                System.out.println(latitude);
                System.out.println(longitude);

            }


        }

        Assert.assertEquals(latitude, actualLatitude);
        Assert.assertEquals(longitude, actualLongitude);





    }
}
